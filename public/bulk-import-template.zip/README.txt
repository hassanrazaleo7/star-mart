STAR MART BULK IMPORT

1. Replace sample rows in customers.csv and products.csv. Save both as UTF-8 CSV.
2. Put product photos in images/. In products.csv, image_filename must match a photo exactly. Leave blank if no photo.
3. Select customers.csv, products.csv and images folder together, then create a ZIP. Do not nest an additional folder if possible.
4. In /admin > Bulk import, select ZIP and click Import ZIP once. Existing emails and SKUs are skipped.
5. Temporary customer passwords must be unique and communicated privately. Never upload your filled ZIP publicly or commit it to GitHub.
6. Allowed photo types: JPG, PNG, WebP. Import resizes large photos before upload. ZIP up to 30 MB, 5000 rows each.
7. Categories: Fruits; Vegetables; Dairy & Eggs; Bakery; Meat & Poultry; Fish & Seafood; Rice & Grains; Flour & Baking; Pulses & Lentils; Cooking Oil & Ghee; Spices & Condiments; Tea & Coffee; Beverages; Snacks & Sweets; Frozen Foods; Canned & Packaged; Personal Care; Household Cleaning; Baby Care; Pet Supplies; Other.
8. For customer records without an email address, first obtain a valid email or add the customer at POS after creating an account.
